/* eslint no-var: 0, vars-on-top: 0 */
require('babel/register');
var config = require('./webpack/docs.config');
module.exports = config;
