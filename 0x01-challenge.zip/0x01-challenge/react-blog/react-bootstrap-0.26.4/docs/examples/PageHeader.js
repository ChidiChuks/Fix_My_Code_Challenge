const pageHeaderInstance = (
  <PageHeader>Example page header <small>Subtext for header</small></PageHeader>
);

React.render(pageHeaderInstance, mountNode);
